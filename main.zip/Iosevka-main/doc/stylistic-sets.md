# List of Stylistic Sets of Iosevka

<!-- BEGIN Section-OT-Stylistic-Sets -->
<!-- THIS SECTION IS AUTOMATICALLY GENERATED. DO NOT EDIT. -->

<table>
<tr>
<td colspan="2"><code>ss01</code> — Andale Mono Style</td>
</tr>
<tr><td><img src="../images/ss-u-ss01-1.light.svg#gh-light-mode-only"/><img src="../images/ss-u-ss01-1.dark.svg#gh-dark-mode-only"/></td><td><img src="../images/ss-i-ss01-1.light.svg#gh-light-mode-only"/><img src="../images/ss-i-ss01-1.dark.svg#gh-dark-mode-only"/></td></tr>
<tr>
<td colspan="2"><code>ss02</code> — Anonymous Pro Style</td>
</tr>
<tr><td><img src="../images/ss-u-ss02-1.light.svg#gh-light-mode-only"/><img src="../images/ss-u-ss02-1.dark.svg#gh-dark-mode-only"/></td><td><img src="../images/ss-i-ss02-1.light.svg#gh-light-mode-only"/><img src="../images/ss-i-ss02-1.dark.svg#gh-dark-mode-only"/></td></tr>
<tr>
<td colspan="2"><code>ss03</code> — Consolas Style</td>
</tr>
<tr><td><img src="../images/ss-u-ss03-1.light.svg#gh-light-mode-only"/><img src="../images/ss-u-ss03-1.dark.svg#gh-dark-mode-only"/></td><td><img src="../images/ss-i-ss03-1.light.svg#gh-light-mode-only"/><img src="../images/ss-i-ss03-1.dark.svg#gh-dark-mode-only"/></td></tr>
<tr>
<td colspan="2"><code>ss04</code> — Menlo Style</td>
</tr>
<tr><td><img src="../images/ss-u-ss04-1.light.svg#gh-light-mode-only"/><img src="../images/ss-u-ss04-1.dark.svg#gh-dark-mode-only"/></td><td><img src="../images/ss-i-ss04-1.light.svg#gh-light-mode-only"/><img src="../images/ss-i-ss04-1.dark.svg#gh-dark-mode-only"/></td></tr>
<tr>
<td colspan="2"><code>ss05</code> — Fira Mono Style</td>
</tr>
<tr><td><img src="../images/ss-u-ss05-1.light.svg#gh-light-mode-only"/><img src="../images/ss-u-ss05-1.dark.svg#gh-dark-mode-only"/></td><td><img src="../images/ss-i-ss05-1.light.svg#gh-light-mode-only"/><img src="../images/ss-i-ss05-1.dark.svg#gh-dark-mode-only"/></td></tr>
<tr>
<td colspan="2"><code>ss06</code> — Liberation Mono Style</td>
</tr>
<tr><td><img src="../images/ss-u-ss06-1.light.svg#gh-light-mode-only"/><img src="../images/ss-u-ss06-1.dark.svg#gh-dark-mode-only"/></td><td><img src="../images/ss-i-ss06-1.light.svg#gh-light-mode-only"/><img src="../images/ss-i-ss06-1.dark.svg#gh-dark-mode-only"/></td></tr>
<tr>
<td colspan="2"><code>ss07</code> — Monaco Style</td>
</tr>
<tr><td><img src="../images/ss-u-ss07-1.light.svg#gh-light-mode-only"/><img src="../images/ss-u-ss07-1.dark.svg#gh-dark-mode-only"/></td><td><img src="../images/ss-i-ss07-1.light.svg#gh-light-mode-only"/><img src="../images/ss-i-ss07-1.dark.svg#gh-dark-mode-only"/></td></tr>
<tr>
<td colspan="2"><code>ss08</code> — Pragmata Pro Style</td>
</tr>
<tr><td><img src="../images/ss-u-ss08-1.light.svg#gh-light-mode-only"/><img src="../images/ss-u-ss08-1.dark.svg#gh-dark-mode-only"/></td><td><img src="../images/ss-i-ss08-1.light.svg#gh-light-mode-only"/><img src="../images/ss-i-ss08-1.dark.svg#gh-dark-mode-only"/></td></tr>
<tr>
<td colspan="2"><code>ss09</code> — Source Code Pro Style</td>
</tr>
<tr><td><img src="../images/ss-u-ss09-1.light.svg#gh-light-mode-only"/><img src="../images/ss-u-ss09-1.dark.svg#gh-dark-mode-only"/></td><td><img src="../images/ss-i-ss09-1.light.svg#gh-light-mode-only"/><img src="../images/ss-i-ss09-1.dark.svg#gh-dark-mode-only"/></td></tr>
<tr>
<td colspan="2"><code>ss10</code> — Envy Code R Style</td>
</tr>
<tr><td><img src="../images/ss-u-ss10-1.light.svg#gh-light-mode-only"/><img src="../images/ss-u-ss10-1.dark.svg#gh-dark-mode-only"/></td><td><img src="../images/ss-i-ss10-1.light.svg#gh-light-mode-only"/><img src="../images/ss-i-ss10-1.dark.svg#gh-dark-mode-only"/></td></tr>
<tr>
<td colspan="2"><code>ss11</code> — X Window Style</td>
</tr>
<tr><td><img src="../images/ss-u-ss11-1.light.svg#gh-light-mode-only"/><img src="../images/ss-u-ss11-1.dark.svg#gh-dark-mode-only"/></td><td><img src="../images/ss-i-ss11-1.light.svg#gh-light-mode-only"/><img src="../images/ss-i-ss11-1.dark.svg#gh-dark-mode-only"/></td></tr>
<tr>
<td colspan="2"><code>ss12</code> — Ubuntu Mono Style</td>
</tr>
<tr><td><img src="../images/ss-u-ss12-1.light.svg#gh-light-mode-only"/><img src="../images/ss-u-ss12-1.dark.svg#gh-dark-mode-only"/></td><td><img src="../images/ss-i-ss12-1.light.svg#gh-light-mode-only"/><img src="../images/ss-i-ss12-1.dark.svg#gh-dark-mode-only"/></td></tr>
<tr>
<td colspan="2"><code>ss13</code> — Lucida Style</td>
</tr>
<tr><td><img src="../images/ss-u-ss13-1.light.svg#gh-light-mode-only"/><img src="../images/ss-u-ss13-1.dark.svg#gh-dark-mode-only"/></td><td><img src="../images/ss-i-ss13-1.light.svg#gh-light-mode-only"/><img src="../images/ss-i-ss13-1.dark.svg#gh-dark-mode-only"/></td></tr>
<tr>
<td colspan="2"><code>ss14</code> — JetBrains Mono Style</td>
</tr>
<tr><td><img src="../images/ss-u-ss14-1.light.svg#gh-light-mode-only"/><img src="../images/ss-u-ss14-1.dark.svg#gh-dark-mode-only"/></td><td><img src="../images/ss-i-ss14-1.light.svg#gh-light-mode-only"/><img src="../images/ss-i-ss14-1.dark.svg#gh-dark-mode-only"/></td></tr>
<tr>
<td colspan="2"><code>ss15</code> — IBM Plex Mono Style</td>
</tr>
<tr><td><img src="../images/ss-u-ss15-1.light.svg#gh-light-mode-only"/><img src="../images/ss-u-ss15-1.dark.svg#gh-dark-mode-only"/></td><td><img src="../images/ss-i-ss15-1.light.svg#gh-light-mode-only"/><img src="../images/ss-i-ss15-1.dark.svg#gh-dark-mode-only"/></td></tr>
<tr>
<td colspan="2"><code>ss16</code> — PT Mono Style</td>
</tr>
<tr><td><img src="../images/ss-u-ss16-1.light.svg#gh-light-mode-only"/><img src="../images/ss-u-ss16-1.dark.svg#gh-dark-mode-only"/></td><td><img src="../images/ss-i-ss16-1.light.svg#gh-light-mode-only"/><img src="../images/ss-i-ss16-1.dark.svg#gh-dark-mode-only"/></td></tr>
<tr>
<td colspan="2"><code>ss17</code> — Recursive Mono Style</td>
</tr>
<tr><td><img src="../images/ss-u-ss17-1.light.svg#gh-light-mode-only"/><img src="../images/ss-u-ss17-1.dark.svg#gh-dark-mode-only"/></td><td><img src="../images/ss-i-ss17-1.light.svg#gh-light-mode-only"/><img src="../images/ss-i-ss17-1.dark.svg#gh-dark-mode-only"/></td></tr>
<tr>
<td colspan="2"><code>ss18</code> — Input Mono Style</td>
</tr>
<tr><td><img src="../images/ss-u-ss18-1.light.svg#gh-light-mode-only"/><img src="../images/ss-u-ss18-1.dark.svg#gh-dark-mode-only"/></td><td><img src="../images/ss-i-ss18-1.light.svg#gh-light-mode-only"/><img src="../images/ss-i-ss18-1.dark.svg#gh-dark-mode-only"/></td></tr>
<tr>
<td colspan="2"><code>ss20</code> — Curly Style</td>
</tr>
<tr><td><img src="../images/ss-u-ss20-1.light.svg#gh-light-mode-only"/><img src="../images/ss-u-ss20-1.dark.svg#gh-dark-mode-only"/></td><td><img src="../images/ss-i-ss20-1.light.svg#gh-light-mode-only"/><img src="../images/ss-i-ss20-1.dark.svg#gh-dark-mode-only"/></td></tr>
</table>

<!-- END Section-OT-Stylistic-Sets -->
