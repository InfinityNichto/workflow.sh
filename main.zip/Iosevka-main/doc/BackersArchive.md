# Backers Archive

This is an archive of former backers that sponsored Iosevka’s development during 0.x–2.x period. Iosevka will continue evolving, and thank you for your support.

## Generous Backers

- Cheng-Wei Chien
- Tianyu Ge
- (Anonymous User 4362976)
- Delton Ding
- Codi Matters
- Vasily Shmelev

## Backers

- Danny O'Brien
- Yanjia Huang
- Leon Breedt
- Alexander Payne
- Marek Kubica
- Yoshito Komatsu
- Dylan Sinnott
- robertgzr
- Pavlos Vinieratos
- Matthew Piziak
- Winnie Quinn
- Clemens
- Pascal
- Kevin Sidarous
- Beni Cherniavsky-Paskin
- Bartłomiej T. Listwon
- Will Binns-Smith
- Jeff S
- Jeri Mason
- Michael L. Ward
- Freetasy
